package parkingmanagement.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBconnection {
	
	
	 static Connection c=null;
		
		public static Connection Dowcon() {
			
			try {
				
				Class.forName("com.mysql.jdbc.Driver");
				c=DriverManager.getConnection("jdbc:mysql://localhost:3306/parking_system","root","root");
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			return c;

}
}
