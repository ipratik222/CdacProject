package parkingmanagement.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import parkingmanagement.dao.DBconnection;

/**
 * Servlet implementation class Addlocation
 */
@WebServlet("/addlocation")
public class Addlocation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Addlocation() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String loc = request.getParameter("loc");
            
           
            
            System.out.println(loc);

            Connection conn = DBconnection.Dowcon();
            String message = null;

            try {
                

                    String sql = "insert into locations (city) values(?)";
                    PreparedStatement statement = conn.prepareStatement(sql);
                    statement.setString(1, loc);
                    
                    
                    int row = statement.executeUpdate();
                    if (row > 0) {

                        response.sendRedirect("addlocation.jsp?Success");
                    } else {
                        response.sendRedirect("addlocation.jsp?Register_Failed");
                    }
                
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        
	
        }}
}
